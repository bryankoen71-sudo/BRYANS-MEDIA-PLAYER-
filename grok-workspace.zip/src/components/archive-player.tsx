import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  Check,
  ChevronDown,
  ChevronUp,
  CircleHelp,
  Clapperboard,
  ExternalLink,
  Film,
  ListVideo,
  Maximize,
  Pause,
  PictureInPicture2,
  Play,
  Repeat,
  Repeat1,
  ScanSearch,
  Search,
  Shuffle,
  SkipBack,
  SkipForward,
  Trash2,
  TriangleAlert,
  Volume2,
} from "lucide-react";
import {
  DEMO_URL,
  DEFAULT_ARCHIVE,
  type Clip,
  extractFromHtml,
  extractUrls,
  formatDuration,
  loadSaved,
  newId,
  parseImport,
  resolveUrl,
  saveSaved,
  titleFromUrl,
  toJson,
  toM3u,
} from "@/lib/archive";

type RepeatMode = "off" | "all" | "one";
type Notice = { kind: "ok" | "err"; text: string };

const RATES = [0.5, 0.75, 1, 1.25, 1.5, 2];

const STEPS = [
  ["1", "Keep your archive server running"],
  ["2", "Open this app in the same browser — no account"],
  ["3", "Connect / Scan. If the browser blocks it, paste the page HTML"],
  ["4", "Press Play All"],
];

export function ArchivePlayer() {
  const [items, setItems] = useState<Clip[]>([]);
  const [base, setBase] = useState(DEFAULT_ARCHIVE);
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState<RepeatMode>("off");
  const [rate, setRate] = useState(1);
  const [volume, setVolume] = useState(1);
  const [query, setQuery] = useState("");
  const [htmlPaste, setHtmlPaste] = useState("");
  const [singleUrl, setSingleUrl] = useState("");
  const [multiUrls, setMultiUrls] = useState("");
  const [importText, setImportText] = useState("");
  const [exportKind, setExportKind] = useState<"json" | "m3u">("json");
  const [exportText, setExportText] = useState("");
  const [notice, setNotice] = useState<Notice | null>(null);
  const [helpOpen, setHelpOpen] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [durations, setDurations] = useState<Record<string, number>>({});
  const [installEvent, setInstallEvent] = useState<InstallPromptEvent | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const shellRef = useRef<HTMLDivElement>(null);
  const exportRef = useRef<HTMLTextAreaElement>(null);
  const wantPlay = useRef(false);
  const playingRef = useRef(false);

  useEffect(() => {
    const saved = loadSaved();
    setItems(saved.items);
    setBase(saved.base);
    setHydrated(true);
    const onInstall = (event: Event) => {
      event.preventDefault();
      setInstallEvent(event as InstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onInstall);
    return () => window.removeEventListener("beforeinstallprompt", onInstall);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    saveSaved({ base, items });
  }, [hydrated, base, items]);

  useEffect(() => {
    playingRef.current = playing;
  }, [playing]);

  const current = items[index];

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    video.playbackRate = rate;
    video.volume = volume;
  }, [rate, volume, current?.id]);

  useEffect(() => {
    if (!wantPlay.current) return;
    const video = videoRef.current;
    if (!video || !current) return;
    wantPlay.current = false;
    video.play().catch(() => {
      setPlaying(false);
      flash(
        "err",
        "This video could not start. Check that the archive server is running and the URL is reachable in this browser.",
      );
    });
  }, [current?.id, index]);

  useEffect(() => {
    if (!current || !("mediaSession" in navigator)) return;
    navigator.mediaSession.metadata = new MediaMetadata({
      title: current.title,
      artist: "Archive Player",
    });
    navigator.mediaSession.setActionHandler("previoustrack", () => goPrev());
    navigator.mediaSession.setActionHandler("nexttrack", () => goNext(false));
  }, [current?.id, current?.title, index, items.length, shuffle, repeat]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing =
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.tagName === "SELECT" ||
          target.isContentEditable);
      if (typing) return;
      if (event.code === "Space") {
        event.preventDefault();
        togglePlay();
      } else if (event.code === "ArrowRight") {
        goNext(false);
      } else if (event.code === "ArrowLeft") {
        goPrev();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return items;
    return items.filter(
      (item) => item.title.toLowerCase().includes(q) || item.url.toLowerCase().includes(q),
    );
  }, [items, query]);

  function flash(kind: Notice["kind"], text: string) {
    setNotice({ kind, text });
  }

  function jump(next: number, autoplay: boolean) {
    if (next < 0 || next >= items.length) return;
    if (autoplay) {
      wantPlay.current = true;
      setPlaying(true);
      if (next === index) {
        videoRef.current?.play().catch(() => {
          setPlaying(false);
          flash(
            "err",
            "This video could not start. Check that the archive server is running and the URL is reachable in this browser.",
          );
        });
      }
    }
    setIndex(next);
  }

  function goNext(forceWrap: boolean) {
    if (!items.length) return;
    if (shuffle && items.length > 1) {
      let next = index;
      while (next === index) next = Math.floor(Math.random() * items.length);
      jump(next, playingRef.current || forceWrap);
      return;
    }
    if (index < items.length - 1) jump(index + 1, playingRef.current || forceWrap);
    else if (repeat === "all" || forceWrap) jump(0, playingRef.current || forceWrap);
  }

  function goPrev() {
    if (!items.length) return;
    jump(index === 0 ? items.length - 1 : index - 1, playingRef.current);
  }

  function onEnded() {
    const video = videoRef.current;
    if (repeat === "one" && video) {
      video.currentTime = 0;
      video.play().catch(() => setPlaying(false));
      return;
    }
    if (index < items.length - 1 || repeat === "all" || shuffle) {
      goNext(true);
      return;
    }
    setPlaying(false);
  }

  function togglePlay() {
    const video = videoRef.current;
    if (!video || !current) return;
    if (video.paused) {
      video.play().catch(() =>
        flash(
          "err",
          "This video could not start. Check that the archive server is running and the URL is reachable in this browser.",
        ),
      );
    } else {
      video.pause();
    }
  }

  function addUrls(urls: string[]) {
    const existing = new Set(items.map((item) => item.url));
    const fresh: string[] = [];
    for (const url of urls) {
      if (!url || existing.has(url) || fresh.includes(url)) continue;
      fresh.push(url);
    }
    if (!fresh.length) {
      flash("ok", "No new videos to add — those URLs are already in the playlist.");
      return 0;
    }
    const start = items.reduce((max, item) => Math.max(max, item.order), 0);
    const next = fresh.map((url, i) => ({
      id: newId(),
      url,
      title: titleFromUrl(url),
      order: start + (i + 1) * 10,
    }));
    setItems((prev) => [...prev, ...next]);
    flash("ok", `Added ${next.length} video${next.length === 1 ? "" : "s"} to the playlist.`);
    return next.length;
  }

  async function scan() {
    const target = base.trim();
    if (!target) {
      flash("err", "Enter an archive viewer URL first.");
      return;
    }
    setBusy(true);
    setNotice(null);
    try {
      const response = await fetch(target);
      if (!response.ok) throw new Error(`The archive page returned ${response.status}.`);
      const html = await response.text();
      const urls = extractFromHtml(html, target);
      if (!urls.length) {
        flash(
          "err",
          "Connected, but no video URLs were found on that page. Paste the page HTML below instead.",
        );
        document.getElementById("paste-html")?.scrollIntoView({ behavior: "smooth", block: "center" });
        return;
      }
      addUrls(urls);
    } catch {
      flash(
        "err",
        "Direct scan was blocked — browsers refuse cross-origin fetches unless the archive sends the right headers. Paste the page HTML below, or add URLs directly. Nothing was fetched.",
      );
      document.getElementById("paste-html")?.scrollIntoView({ behavior: "smooth", block: "center" });
    } finally {
      setBusy(false);
    }
  }

  function parseHtml() {
    if (!htmlPaste.trim()) {
      flash("err", "Paste page HTML first.");
      return;
    }
    const urls = extractFromHtml(htmlPaste, base);
    if (!urls.length) {
      flash("err", "No video URLs found in that HTML. Try Paste Multiple URLs instead.");
      return;
    }
    flash("ok", `Found ${urls.length} video URL${urls.length === 1 ? "" : "s"} in the pasted HTML.`);
    addUrls(urls);
  }

  function addSingle() {
    const url = resolveUrl(singleUrl, base);
    if (!url) {
      flash("err", "Enter a video URL first.");
      return;
    }
    if (addUrls([url])) setSingleUrl("");
  }

  function addMany() {
    const fromText = extractUrls(multiUrls, base);
    const loose = multiUrls
      .split(/\s+/)
      .map((line) => resolveUrl(line, base))
      .filter((url): url is string => Boolean(url));
    const urls = [...new Set([...fromText, ...loose])];
    if (!urls.length) {
      flash("err", "Paste at least one video URL, one per line.");
      return;
    }
    addUrls(urls);
  }

  function importPlaylist() {
    const urls = parseImport(importText, base);
    if (!urls.length) {
      flash("err", importText.trim() ? "No playable URLs found in that import text." : "Paste playlist JSON or M3U text first.");
      return;
    }
    addUrls(urls);
  }

  function exportPlaylist() {
    if (!items.length) {
      flash("err", "Playlist is empty — nothing to export.");
      return;
    }
    setExportText(exportKind === "json" ? toJson(items) : toM3u(items));
    flash("ok", "Export ready below. Select the text to keep a copy.");
  }

  async function copyExport() {
    exportRef.current?.select();
    try {
      await navigator.clipboard.writeText(exportText);
      setCopied(true);
    } catch {
      try {
        document.execCommand("copy");
        setCopied(true);
      } catch {
        setCopied(false);
      }
    }
    window.setTimeout(() => setCopied(false), 2000);
  }

  function removeItem(id: string) {
    const removed = items.findIndex((item) => item.id === id);
    if (removed < 0) return;
    const next = items.filter((item) => item.id !== id);
    setItems(next);
    if (removed === index) setPlaying(false);
    setIndex((value) => {
      const shifted = removed < value ? value - 1 : value;
      return Math.max(0, Math.min(shifted, next.length - 1));
    });
    flash("ok", "Removed from playlist.");
  }

  function clearAll() {
    setItems([]);
    setIndex(0);
    setPlaying(false);
    setConfirmClear(false);
    flash("ok", "Playlist cleared.");
  }

  function move(from: number, delta: number) {
    const to = from + delta;
    if (to < 0 || to >= items.length) return;
    const next = items.slice();
    const a = next[from];
    const b = next[to];
    next[from] = { ...b, order: a.order };
    next[to] = { ...a, order: b.order };
    next.sort((x, y) => x.order - y.order);
    setItems(next);
    if (index === from) setIndex(to);
    else if (index === to) setIndex(from);
  }

  async function install() {
    if (!installEvent) {
      flash(
        "ok",
        "Install prompt is not available yet. In your browser menu, use “Add to Home Screen” or “Install app” when it appears.",
      );
      return;
    }
    try {
      await installEvent.prompt();
      setInstallEvent(null);
    } catch {
      flash("err", "Install prompt could not be opened.");
    }
  }

  async function pip() {
    const video = videoRef.current;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        return;
      }
      if (video && "requestPictureInPicture" in video) await video.requestPictureInPicture();
      else throw new Error("unavailable");
    } catch {
      flash("err", "Picture-in-picture is not available for this video in this browser.");
    }
  }

  function fullscreen() {
    const shell = shellRef.current;
    if (!shell) return;
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => undefined);
      return;
    }
    shell.requestFullscreen?.().catch(() => undefined);
  }

  function cycleRepeat() {
    setRepeat((mode) => (mode === "off" ? "all" : mode === "all" ? "one" : "off"));
  }

  const repeatLabel = repeat === "off" ? "Repeat: Off" : repeat === "all" ? "Repeat: All" : "Repeat: One";

  return (
    <div className="safe-pad min-h-screen bg-bg text-ink">
      <header className="sticky top-0 z-20 border-b border-line bg-bg/95 backdrop-blur">
        <div className="mx-auto max-w-7xl px-4 py-3 sm:px-6">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex min-w-0 items-center gap-3">
              <div className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-accent text-accent-ink">
                <Film className="size-5" aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <h1 className="text-2xl leading-none font-extrabold tracking-tight">ARCHIVE PLAYER</h1>
                <p className="mt-1 text-xs text-muted">Play your local archive · Saved on this device · No login</p>
              </div>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <button
                type="button"
                onClick={install}
                className="h-11 rounded-full border border-line px-4 text-sm font-semibold"
              >
                <span className="hidden sm:inline">Install app</span>
                <span className="sm:hidden">Install</span>
              </button>
              <button
                type="button"
                onClick={() => setHelpOpen((open) => !open)}
                className="flex h-11 items-center gap-1 rounded-full border border-line px-4 text-sm font-semibold"
                aria-expanded={helpOpen}
              >
                <CircleHelp className="size-4" aria-hidden="true" />
                Help
              </button>
            </div>
          </div>
          <div className="mt-3 flex flex-col gap-2 sm:flex-row">
            <label className="min-w-0 flex-1">
              <span className="sr-only">Archive viewer URL</span>
              <input
                value={base}
                onChange={(event) => setBase(event.target.value)}
                className="w-full px-3 py-2.5 font-mono text-sm break-all"
                placeholder="Archive viewer URL"
                spellCheck={false}
              />
            </label>
            <button
              type="button"
              onClick={scan}
              disabled={busy}
              className="flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl bg-accent px-5 font-bold text-accent-ink"
            >
              <ScanSearch className="size-4" aria-hidden="true" />
              {busy ? "Scanning…" : "Connect / Scan"}
            </button>
          </div>
          <p className="mt-2 text-xs text-muted">
            Scan asks your browser to open that page. If the archive blocks it, paste the page source below.
            Nothing is added until a real video URL is found.
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-4 sm:px-6">
        {notice && (
          <div
            role="status"
            className={
              "mb-4 flex items-start gap-2 rounded-xl border px-3 py-2.5 text-sm " +
              (notice.kind === "ok"
                ? "border-ok-line bg-ok-bg text-ok"
                : "border-bad-line bg-bad-bg text-bad")
            }
          >
            {notice.kind === "ok" ? (
              <Check className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
            ) : (
              <TriangleAlert className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
            )}
            <span className="break-words">{notice.text}</span>
          </div>
        )}

        {helpOpen && (
          <section className="mb-4 rounded-2xl border border-line bg-card p-4 sm:p-5">
            <h2 className="flex items-center gap-2 text-lg font-bold">
              <CircleHelp className="size-5 text-accent" aria-hidden="true" />
              How to use with your local server
            </h2>
            <ol className="mt-3 grid gap-3 text-sm leading-relaxed sm:grid-cols-2 lg:grid-cols-4">
              {STEPS.map(([n, text]) => (
                <li key={n} className="rounded-xl bg-card-2 p-3">
                  <span className="text-2xl font-extrabold text-accent">{n}</span>
                  <p className="mt-1">{text}</p>
                </li>
              ))}
            </ol>
            <p className="mt-3 text-xs leading-relaxed text-muted">
              Playlist order lives in this browser only. Playback still needs the archive server, or a video URL
              this browser can reach. Space plays and pauses. Left and right arrows change tracks.
            </p>
          </section>
        )}

        <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,1fr)_24rem]">
          <section className="min-w-0">
            <div ref={shellRef} className="overflow-hidden rounded-2xl border border-line bg-black">
              {current ? (
                <video
                  ref={videoRef}
                  key={current.id}
                  src={current.url}
                  controls
                  playsInline
                  preload="metadata"
                  className="block aspect-video w-full bg-black"
                  onPlay={() => setPlaying(true)}
                  onPause={() => setPlaying(false)}
                  onEnded={onEnded}
                  onLoadedMetadata={(event) => {
                    const duration = event.currentTarget.duration;
                    if (Number.isFinite(duration)) {
                      setDurations((prev) => ({ ...prev, [current.id]: duration }));
                    }
                  }}
                  onError={() =>
                    flash(
                      "err",
                      "This video could not load. Check that the archive server is running and the URL is reachable in this browser.",
                    )
                  }
                />
              ) : (
                <div className="flex aspect-video flex-col items-center justify-center gap-3 px-6 text-center">
                  <Clapperboard className="size-11 text-accent" aria-hidden="true" />
                  <div>
                    <p className="text-xl font-bold">No video selected yet</p>
                    <p className="mt-1 text-sm text-muted">
                      Add videos below, or add the labelled demo clip to try the player.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => addUrls([DEMO_URL])}
                    className="rounded-xl bg-accent px-4 py-2.5 text-sm font-bold text-accent-ink"
                  >
                    Add demo video
                  </button>
                </div>
              )}
            </div>

            <div className="mt-3 rounded-2xl border border-line bg-card p-4">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-xs font-semibold tracking-widest text-accent uppercase">Now playing</p>
                  <h2 className="mt-1 text-xl leading-tight font-bold break-words">
                    {current ? current.title : "—"}
                  </h2>
                </div>
                <span className="shrink-0 rounded-full border border-line px-2.5 py-1 font-mono text-sm">
                  {items.length ? `${index + 1} / ${items.length}` : "0 / 0"}
                </span>
              </div>
              {current && (
                <a
                  href={current.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 block font-mono text-xs break-all text-muted underline decoration-dotted"
                >
                  {current.url} <ExternalLink className="inline size-3" aria-hidden="true" />
                </a>
              )}

              <div className="mt-4 flex flex-wrap items-center gap-2">
                <IconButton label="Previous" onClick={goPrev} disabled={!items.length}>
                  <SkipBack className="size-5" />
                </IconButton>
                <button
                  type="button"
                  onClick={togglePlay}
                  disabled={!current}
                  aria-label={playing ? "Pause" : "Play"}
                  className="flex size-14 items-center justify-center rounded-full bg-accent text-accent-ink"
                >
                  {playing ? <Pause className="size-6" /> : <Play className="ml-0.5 size-6" />}
                </button>
                <IconButton label="Next" onClick={() => goNext(false)} disabled={!items.length}>
                  <SkipForward className="size-5" />
                </IconButton>
                <button
                  type="button"
                  onClick={() => setShuffle((on) => !on)}
                  aria-pressed={shuffle}
                  className={
                    "flex h-11 items-center gap-1.5 rounded-full border px-3 text-sm font-semibold " +
                    (shuffle ? "border-accent text-accent" : "border-line")
                  }
                >
                  <Shuffle className="size-4" aria-hidden="true" />
                  Shuffle
                </button>
                <button
                  type="button"
                  onClick={cycleRepeat}
                  aria-label="Repeat"
                  className={
                    "flex h-11 items-center gap-1.5 rounded-full border px-3 text-sm font-semibold " +
                    (repeat !== "off" ? "border-accent text-accent" : "border-line")
                  }
                >
                  {repeat === "one" ? (
                    <Repeat1 className="size-4" aria-hidden="true" />
                  ) : (
                    <Repeat className="size-4" aria-hidden="true" />
                  )}
                  {repeatLabel}
                </button>
                <button
                  type="button"
                  onClick={() => items.length && jump(0, true)}
                  disabled={!items.length}
                  className="h-11 rounded-full border border-line px-3 text-sm font-semibold"
                >
                  Play all
                </button>
              </div>

              <div className="mt-4 flex flex-wrap items-center gap-4 text-sm">
                <label className="flex items-center gap-2">
                  Speed
                  <select
                    value={rate}
                    onChange={(event) => setRate(Number(event.target.value))}
                    className="px-2 py-1.5"
                  >
                    {RATES.map((value) => (
                      <option key={value} value={value}>
                        {value}×
                      </option>
                    ))}
                  </select>
                </label>
                <label className="flex min-w-44 flex-1 items-center gap-2">
                  <Volume2 className="size-4" aria-hidden="true" />
                  <span className="sr-only">Volume</span>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={volume}
                    onChange={(event) => setVolume(Number(event.target.value))}
                    className="w-full"
                  />
                </label>
                <button
                  type="button"
                  onClick={pip}
                  className="flex h-11 items-center gap-1.5 rounded-full border border-line px-3 text-sm"
                >
                  <PictureInPicture2 className="size-4" aria-hidden="true" />
                  PiP
                </button>
                <button
                  type="button"
                  onClick={fullscreen}
                  className="flex h-11 items-center gap-1.5 rounded-full border border-line px-3 text-sm"
                >
                  <Maximize className="size-4" aria-hidden="true" />
                  Fullscreen
                </button>
              </div>
              <p className="mt-3 flex items-center gap-1.5 text-xs text-muted">
                Autoplay next follows shuffle and repeat. Use the player bar to seek inside a video.
              </p>
            </div>

            <div className="mt-4 grid gap-4 md:grid-cols-2">
              <section className="rounded-2xl border border-line bg-card p-4">
                <h3 className="flex items-center gap-2 font-bold">
                  <Clapperboard className="size-4 text-accent" aria-hidden="true" />
                  Paste page HTML
                </h3>
                <p className="mt-1 text-xs text-muted">
                  On the archive page: View Source, copy, paste. Video, source, and link URLs are pulled out.
                </p>
                <textarea
                  id="paste-html"
                  value={htmlPaste}
                  onChange={(event) => setHtmlPaste(event.target.value)}
                  rows={5}
                  className="mt-3 w-full px-3 py-2 font-mono text-xs"
                  placeholder="Paste the archive page HTML here…"
                />
                <button
                  type="button"
                  disabled={busy}
                  onClick={parseHtml}
                  className="mt-2 h-11 w-full rounded-xl bg-accent text-sm font-bold text-accent-ink"
                >
                  Parse HTML and add videos
                </button>
              </section>

              <section className="rounded-2xl border border-line bg-card p-4">
                <h3 className="flex items-center gap-2 font-bold">
                  <Film className="size-4 text-accent" aria-hidden="true" />
                  Add video URL
                </h3>
                <p className="mt-1 text-xs text-muted">One direct mp4, webm, mov, or m3u8 link.</p>
                <input
                  value={singleUrl}
                  onChange={(event) => setSingleUrl(event.target.value)}
                  className="mt-3 w-full px-3 py-2.5 font-mono text-sm"
                  placeholder="https://…/clip.mp4"
                  spellCheck={false}
                />
                <button
                  type="button"
                  disabled={busy}
                  onClick={addSingle}
                  className="mt-2 h-11 w-full rounded-xl border border-line text-sm font-bold"
                >
                  Add video
                </button>
                <label className="mt-4 block text-xs font-semibold">
                  Paste multiple URLs <span className="font-normal text-muted">— one per line</span>
                  <textarea
                    value={multiUrls}
                    onChange={(event) => setMultiUrls(event.target.value)}
                    rows={3}
                    className="mt-2 w-full px-3 py-2 font-mono text-xs font-normal"
                    placeholder={"https://…/one.mp4\nhttps://…/two.webm"}
                  />
                </label>
                <button
                  type="button"
                  disabled={busy}
                  onClick={addMany}
                  className="mt-2 h-11 w-full rounded-xl border border-line text-sm font-bold"
                >
                  Add all URLs
                </button>
              </section>
            </div>

            <section className="mt-4 rounded-2xl border border-line bg-card p-4">
              <h3 className="font-bold">Import / export playlist</h3>
              <div className="mt-3 grid gap-3 md:grid-cols-2">
                <div>
                  <label className="text-xs font-semibold">
                    Import JSON or M3U
                    <textarea
                      value={importText}
                      onChange={(event) => setImportText(event.target.value)}
                      rows={5}
                      className="mt-2 w-full px-3 py-2 font-mono text-xs font-normal"
                      placeholder='[{"title":"Clip","url":"https://…"}] or #EXTM3U…'
                    />
                  </label>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={importPlaylist}
                    className="mt-2 h-11 w-full rounded-xl border border-line text-sm font-bold"
                  >
                    Import pasted playlist
                  </button>
                </div>
                <div>
                  <p className="text-xs font-semibold">Export</p>
                  <div className="mt-2 flex gap-2">
                    <select
                      value={exportKind}
                      onChange={(event) => setExportKind(event.target.value as "json" | "m3u")}
                      className="px-2 py-2 text-sm"
                    >
                      <option value="json">JSON</option>
                      <option value="m3u">M3U</option>
                    </select>
                    <button
                      type="button"
                      onClick={exportPlaylist}
                      className="h-11 flex-1 rounded-xl bg-accent text-sm font-bold text-accent-ink"
                    >
                      Generate
                    </button>
                  </div>
                  <textarea
                    ref={exportRef}
                    value={exportText}
                    readOnly
                    rows={5}
                    className="mt-2 w-full px-3 py-2 font-mono text-xs"
                    placeholder="Export output appears here…"
                  />
                  <button
                    type="button"
                    onClick={copyExport}
                    disabled={!exportText}
                    className="mt-2 h-11 w-full rounded-xl border border-line text-sm"
                  >
                    {copied ? "Copied" : "Select and copy export text"}
                  </button>
                </div>
              </div>
              <p className="mt-2 text-xs text-muted">
                Local files cannot be opened from here. Point at them with a URL your archive server already serves.
              </p>
            </section>
          </section>

          <aside className="rounded-2xl border border-line bg-card p-4 lg:sticky lg:top-28">
            <div className="flex items-center justify-between gap-2">
              <h2 className="flex items-center gap-2 text-lg font-bold">
                <ListVideo className="size-5 text-accent" aria-hidden="true" />
                Playlist
              </h2>
              <span className="rounded-full border border-line px-2 py-1 text-xs">
                {items.length} videos
              </span>
            </div>
            <label className="relative mt-3 block">
              <Search
                className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted"
                aria-hidden="true"
              />
              <span className="sr-only">Search playlist</span>
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                className="w-full py-2.5 pr-3 pl-9 text-sm"
                placeholder="Search title or URL…"
              />
            </label>
            <div className="mt-3 flex gap-2">
              <button
                type="button"
                onClick={() => items.length && jump(0, true)}
                disabled={!items.length}
                className="flex h-11 flex-1 items-center justify-center gap-1 rounded-xl bg-accent text-sm font-bold text-accent-ink"
              >
                <Play className="size-4" aria-hidden="true" />
                Play all
              </button>
              {!confirmClear ? (
                <button
                  type="button"
                  onClick={() => setConfirmClear(true)}
                  disabled={!items.length}
                  className="h-11 flex-1 rounded-xl border border-line text-sm font-bold"
                >
                  Clear all
                </button>
              ) : (
                <button
                  type="button"
                  onClick={clearAll}
                  className="h-11 flex-1 rounded-xl bg-bad text-sm font-bold text-accent-ink"
                >
                  Confirm clear?
                </button>
              )}
            </div>
            <div className="mt-3 grid max-h-[36rem] gap-2 overflow-y-auto">
              {hydrated && !visible.length && (
                <div className="rounded-xl bg-card-2 p-4 text-center text-sm">
                  <Film className="mx-auto mb-2 size-5 text-accent" aria-hidden="true" />
                  <p className="font-semibold">
                    {query ? "No matches for that search." : "Your playlist is empty"}
                  </p>
                  <p className="mt-1 text-xs text-muted">
                    {query ? "Try another title or URL." : "Paste page HTML or add a video URL to get started."}
                  </p>
                </div>
              )}
              {visible.map((item) => {
                const position = items.findIndex((entry) => entry.id === item.id);
                const active = position === index;
                const duration = durations[item.id];
                return (
                  <article
                    key={item.id}
                    className={
                      "flex gap-2.5 rounded-xl border p-2.5 " +
                      (active ? "border-accent bg-now" : "border-line bg-card-2")
                    }
                  >
                    <button
                      type="button"
                      onClick={() => jump(position, true)}
                      aria-label={`Play ${item.title}`}
                      className="relative flex h-12 w-16 shrink-0 flex-col items-center justify-center rounded-lg bg-black text-accent"
                    >
                      <Film className="size-4" aria-hidden="true" />
                      <span className="font-mono text-xs">{String(position + 1).padStart(2, "0")}</span>
                      {active && <span className="absolute top-1 right-1 size-2 rounded-full bg-accent" />}
                    </button>
                    <div className="min-w-0 flex-1">
                      <button type="button" onClick={() => jump(position, true)} className="w-full text-left">
                        <span className="block text-sm leading-snug font-semibold break-words">{item.title}</span>
                        <span className="block truncate font-mono text-xs text-muted">{item.url}</span>
                        <span className="text-xs text-muted">
                          {duration ? formatDuration(duration) : "Duration after playback"}
                          {" · "}
                          {item.url === DEMO_URL ? "Demo" : "Archive"}
                        </span>
                      </button>
                      <div className="mt-1.5 flex gap-1">
                        <IconButton label="Move up" onClick={() => move(position, -1)} disabled={position === 0}>
                          <ChevronUp className="size-4" />
                        </IconButton>
                        <IconButton
                          label="Move down"
                          onClick={() => move(position, 1)}
                          disabled={position === items.length - 1}
                        >
                          <ChevronDown className="size-4" />
                        </IconButton>
                        <button
                          type="button"
                          onClick={() => removeItem(item.id)}
                          className="ml-auto flex h-9 items-center gap-1 rounded-md border border-line px-2 text-xs"
                        >
                          <Trash2 className="size-3.5" aria-hidden="true" />
                          Remove
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
            <p className="mt-3 text-xs leading-relaxed text-muted">
              Order is saved on this device. Up and down work with touch and keyboard — no account, no upload.
            </p>
          </aside>
        </div>
      </main>
      <footer className="mx-auto max-w-7xl px-4 pb-8 text-xs text-muted sm:px-6">
        Archive Player · Standalone · Theme #0f0f0f · Videos are added only when you paste or scan them.
      </footer>
    </div>
  );
}

function IconButton({
  label,
  onClick,
  disabled,
  children,
}: {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      disabled={disabled}
      className="flex size-11 items-center justify-center rounded-full border border-line"
    >
      {children}
    </button>
  );
}

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
};
