export type Clip = {
  id: string;
  url: string;
  title: string;
  order: number;
};

export const DEFAULT_ARCHIVE =
  "http://127.0.0.1:21894/archiveviewer/1800460370/viewer.html";

export const DEMO_URL =
  "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";

const STORAGE_KEY = "archive-player.v1";
const VIDEO_EXT = /\.(mp4|webm|mov|m3u8)(?:\?|#|$)/i;
const ABS_RE =
  /https?:\/\/[^\s"'<>\\]+?\.(?:mp4|webm|mov|m3u8)(?:\?[^\s"'<>]*)?/gi;
const REL_RE =
  /["'=\s](\/[^\s"'<>]+\.(?:mp4|webm|mov|m3u8)(?:\?[^\s"'<>]*)?)/gi;

export function newId(): string {
  try {
    return crypto.randomUUID();
  } catch {
    return `k-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  }
}

export function titleFromUrl(url: string): string {
  try {
    const parsed = new URL(url);
    const parts = parsed.pathname.split("/").filter(Boolean);
    const last = parts[parts.length - 1] || parsed.hostname;
    const name = decodeURIComponent(last).replace(/\.(mp4|webm|mov|m3u8)$/i, "");
    return name.replace(/[-_]+/g, " ").trim() || url;
  } catch {
    const parts = url.split("/").filter(Boolean);
    try {
      return decodeURIComponent(parts[parts.length - 1] || url);
    } catch {
      return url;
    }
  }
}

export function resolveUrl(raw: string, base: string): string | null {
  const trimmed = raw.trim().replace(/^["']|["']$/g, "");
  if (!trimmed || trimmed.startsWith("#")) return null;
  try {
    const url = new URL(trimmed, base || undefined);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return url.toString();
  } catch {
    return null;
  }
}

export function extractUrls(text: string, base: string): string[] {
  const found = new Set<string>();
  for (const match of text.matchAll(ABS_RE)) found.add(match[0]);
  for (const match of text.matchAll(REL_RE)) {
    const resolved = resolveUrl(match[1], base);
    if (resolved) found.add(resolved);
  }
  return [...found];
}

export function extractFromHtml(html: string, base: string): string[] {
  const found = new Set<string>(extractUrls(html, base));
  if (typeof DOMParser === "undefined") return [...found];
  const doc = new DOMParser().parseFromString(html, "text/html");
  const add = (raw: string | null) => {
    if (!raw) return;
    const resolved = resolveUrl(raw, base);
    if (resolved) found.add(resolved);
  };
  doc.querySelectorAll("video").forEach((el) => add(el.getAttribute("src")));
  doc.querySelectorAll("source").forEach((el) => add(el.getAttribute("src")));
  doc.querySelectorAll("a").forEach((el) => {
    const href = el.getAttribute("href") || "";
    if (VIDEO_EXT.test(href)) add(href);
  });
  doc.querySelectorAll("script").forEach((el) => {
    extractUrls(el.textContent || "", base).forEach((url) => found.add(url));
  });
  return [...found];
}

export function parseImport(text: string, base: string): string[] {
  const trimmed = text.trim();
  if (!trimmed) return [];
  try {
    const data = JSON.parse(trimmed) as unknown;
    const list = Array.isArray(data)
      ? data
      : data && typeof data === "object"
        ? ((data as { playlist?: unknown; items?: unknown }).playlist ??
          (data as { items?: unknown }).items ??
          [])
        : [];
    if (!Array.isArray(list)) return [];
    const urls = list
      .map((item) => {
        if (typeof item === "string") return resolveUrl(item, base);
        if (item && typeof item === "object") {
          const rec = item as { url?: unknown; src?: unknown };
          const raw = typeof rec.url === "string" ? rec.url : rec.src;
          return typeof raw === "string" ? resolveUrl(raw, base) : null;
        }
        return null;
      })
      .filter((url): url is string => Boolean(url));
    return [...new Set(urls)];
  } catch {
    const urls = trimmed
      .split(/\s+/)
      .map((line) => line.trim())
      .filter((line) => line && !line.startsWith("#"))
      .map((line) => resolveUrl(line, base))
      .filter((url): url is string => Boolean(url));
    return [...new Set(urls)];
  }
}

export function toJson(items: Clip[]): string {
  return JSON.stringify(
    items.map((item) => ({ title: item.title, url: item.url })),
    null,
    2,
  );
}

export function toM3u(items: Clip[]): string {
  return (
    "#EXTM3U\n" +
    items.map((item) => `#EXTINF:-1,${item.title}\n${item.url}`).join("\n")
  );
}

export type Saved = { base: string; items: Clip[] };

export function loadSaved(): Saved {
  if (typeof localStorage === "undefined") {
    return { base: DEFAULT_ARCHIVE, items: [] };
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { base: DEFAULT_ARCHIVE, items: [] };
    const data = JSON.parse(raw) as Partial<Saved>;
    const items = Array.isArray(data.items)
      ? data.items
          .filter(
            (item): item is Clip =>
              Boolean(item) &&
              typeof item.id === "string" &&
              typeof item.url === "string" &&
              item.url.length > 0,
          )
          .map((item, index) => ({
            id: item.id,
            url: item.url,
            title: typeof item.title === "string" && item.title ? item.title : titleFromUrl(item.url),
            order: typeof item.order === "number" ? item.order : index,
          }))
          .sort((a, b) => a.order - b.order)
      : [];
    return {
      base: typeof data.base === "string" && data.base ? data.base : DEFAULT_ARCHIVE,
      items,
    };
  } catch {
    return { base: DEFAULT_ARCHIVE, items: [] };
  }
}

export function saveSaved(data: Saved) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return "—";
  const total = Math.round(seconds);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}
