import { createFileRoute } from "@tanstack/react-router";
import { ArchivePlayer } from "@/components/archive-player";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <ArchivePlayer />;
}
