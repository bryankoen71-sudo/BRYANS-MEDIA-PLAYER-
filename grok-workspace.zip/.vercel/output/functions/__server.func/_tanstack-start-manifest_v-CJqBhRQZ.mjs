//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CJqBhRQZ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CzNoVDAZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CzNoVDAZ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-6u-CFqs7.js"]
	}
} });
//#endregion
export { tsrStartManifest };
