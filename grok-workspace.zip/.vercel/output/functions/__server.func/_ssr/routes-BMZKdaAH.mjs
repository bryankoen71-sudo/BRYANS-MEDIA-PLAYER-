import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as Check, _ as ExternalLink, a as SkipBack, b as ChevronUp, c as ScanSearch, d as Play, f as PictureInPicture2, g as Film, h as ListVideo, i as SkipForward, l as Repeat, m as Maximize, n as TriangleAlert, o as Shuffle, p as Pause, r as Trash2, s as Search, t as Volume2, u as Repeat1, v as Clapperboard, x as ChevronDown, y as CircleHelp } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BMZKdaAH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEFAULT_ARCHIVE = "http://127.0.0.1:21894/archiveviewer/1800460370/viewer.html";
var DEMO_URL = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";
var STORAGE_KEY = "archive-player.v1";
var VIDEO_EXT = /\.(mp4|webm|mov|m3u8)(?:\?|#|$)/i;
var ABS_RE = /https?:\/\/[^\s"'<>\\]+?\.(?:mp4|webm|mov|m3u8)(?:\?[^\s"'<>]*)?/gi;
var REL_RE = /["'=\s](\/[^\s"'<>]+\.(?:mp4|webm|mov|m3u8)(?:\?[^\s"'<>]*)?)/gi;
function newId() {
	try {
		return crypto.randomUUID();
	} catch {
		return `k-${Date.now()}-${Math.random().toString(36).slice(2)}`;
	}
}
function titleFromUrl(url) {
	try {
		const parsed = new URL(url);
		const parts = parsed.pathname.split("/").filter(Boolean);
		const last = parts[parts.length - 1] || parsed.hostname;
		return decodeURIComponent(last).replace(/\.(mp4|webm|mov|m3u8)$/i, "").replace(/[-_]+/g, " ").trim() || url;
	} catch {
		const parts = url.split("/").filter(Boolean);
		try {
			return decodeURIComponent(parts[parts.length - 1] || url);
		} catch {
			return url;
		}
	}
}
function resolveUrl(raw, base) {
	const trimmed = raw.trim().replace(/^["']|["']$/g, "");
	if (!trimmed || trimmed.startsWith("#")) return null;
	try {
		const url = new URL(trimmed, base || void 0);
		if (url.protocol !== "http:" && url.protocol !== "https:") return null;
		return url.toString();
	} catch {
		return null;
	}
}
function extractUrls(text, base) {
	const found = /* @__PURE__ */ new Set();
	for (const match of text.matchAll(ABS_RE)) found.add(match[0]);
	for (const match of text.matchAll(REL_RE)) {
		const resolved = resolveUrl(match[1], base);
		if (resolved) found.add(resolved);
	}
	return [...found];
}
function extractFromHtml(html, base) {
	const found = new Set(extractUrls(html, base));
	if (typeof DOMParser === "undefined") return [...found];
	const doc = new DOMParser().parseFromString(html, "text/html");
	const add = (raw) => {
		if (!raw) return;
		const resolved = resolveUrl(raw, base);
		if (resolved) found.add(resolved);
	};
	doc.querySelectorAll("video").forEach((el) => add(el.getAttribute("src")));
	doc.querySelectorAll("source").forEach((el) => add(el.getAttribute("src")));
	doc.querySelectorAll("a").forEach((el) => {
		const href = el.getAttribute("href") || "";
		if (VIDEO_EXT.test(href)) add(href);
	});
	doc.querySelectorAll("script").forEach((el) => {
		extractUrls(el.textContent || "", base).forEach((url) => found.add(url));
	});
	return [...found];
}
function parseImport(text, base) {
	const trimmed = text.trim();
	if (!trimmed) return [];
	try {
		const data = JSON.parse(trimmed);
		const list = Array.isArray(data) ? data : data && typeof data === "object" ? data.playlist ?? data.items ?? [] : [];
		if (!Array.isArray(list)) return [];
		const urls = list.map((item) => {
			if (typeof item === "string") return resolveUrl(item, base);
			if (item && typeof item === "object") {
				const rec = item;
				const raw = typeof rec.url === "string" ? rec.url : rec.src;
				return typeof raw === "string" ? resolveUrl(raw, base) : null;
			}
			return null;
		}).filter((url) => Boolean(url));
		return [...new Set(urls)];
	} catch {
		const urls = trimmed.split(/\s+/).map((line) => line.trim()).filter((line) => line && !line.startsWith("#")).map((line) => resolveUrl(line, base)).filter((url) => Boolean(url));
		return [...new Set(urls)];
	}
}
function toJson(items) {
	return JSON.stringify(items.map((item) => ({
		title: item.title,
		url: item.url
	})), null, 2);
}
function toM3u(items) {
	return "#EXTM3U\n" + items.map((item) => `#EXTINF:-1,${item.title}\n${item.url}`).join("\n");
}
function loadSaved() {
	if (typeof localStorage === "undefined") return {
		base: DEFAULT_ARCHIVE,
		items: []
	};
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return {
			base: DEFAULT_ARCHIVE,
			items: []
		};
		const data = JSON.parse(raw);
		const items = Array.isArray(data.items) ? data.items.filter((item) => Boolean(item) && typeof item.id === "string" && typeof item.url === "string" && item.url.length > 0).map((item, index) => ({
			id: item.id,
			url: item.url,
			title: typeof item.title === "string" && item.title ? item.title : titleFromUrl(item.url),
			order: typeof item.order === "number" ? item.order : index
		})).sort((a, b) => a.order - b.order) : [];
		return {
			base: typeof data.base === "string" && data.base ? data.base : DEFAULT_ARCHIVE,
			items
		};
	} catch {
		return {
			base: DEFAULT_ARCHIVE,
			items: []
		};
	}
}
function saveSaved(data) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}
function formatDuration(seconds) {
	if (!Number.isFinite(seconds) || seconds < 0) return "—";
	const total = Math.round(seconds);
	const h = Math.floor(total / 3600);
	const m = Math.floor(total % 3600 / 60);
	const s = total % 60;
	if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
	return `${m}:${String(s).padStart(2, "0")}`;
}
var RATES = [
	.5,
	.75,
	1,
	1.25,
	1.5,
	2
];
var STEPS = [
	["1", "Keep your archive server running"],
	["2", "Open this app in the same browser — no account"],
	["3", "Connect / Scan. If the browser blocks it, paste the page HTML"],
	["4", "Press Play All"]
];
function ArchivePlayer() {
	const [items, setItems] = (0, import_react.useState)([]);
	const [base, setBase] = (0, import_react.useState)(DEFAULT_ARCHIVE);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [shuffle, setShuffle] = (0, import_react.useState)(false);
	const [repeat, setRepeat] = (0, import_react.useState)("off");
	const [rate, setRate] = (0, import_react.useState)(1);
	const [volume, setVolume] = (0, import_react.useState)(1);
	const [query, setQuery] = (0, import_react.useState)("");
	const [htmlPaste, setHtmlPaste] = (0, import_react.useState)("");
	const [singleUrl, setSingleUrl] = (0, import_react.useState)("");
	const [multiUrls, setMultiUrls] = (0, import_react.useState)("");
	const [importText, setImportText] = (0, import_react.useState)("");
	const [exportKind, setExportKind] = (0, import_react.useState)("json");
	const [exportText, setExportText] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [helpOpen, setHelpOpen] = (0, import_react.useState)(false);
	const [confirmClear, setConfirmClear] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [durations, setDurations] = (0, import_react.useState)({});
	const [installEvent, setInstallEvent] = (0, import_react.useState)(null);
	const videoRef = (0, import_react.useRef)(null);
	const shellRef = (0, import_react.useRef)(null);
	const exportRef = (0, import_react.useRef)(null);
	const wantPlay = (0, import_react.useRef)(false);
	const playingRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		const saved = loadSaved();
		setItems(saved.items);
		setBase(saved.base);
		setHydrated(true);
		const onInstall = (event) => {
			event.preventDefault();
			setInstallEvent(event);
		};
		window.addEventListener("beforeinstallprompt", onInstall);
		return () => window.removeEventListener("beforeinstallprompt", onInstall);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		saveSaved({
			base,
			items
		});
	}, [
		hydrated,
		base,
		items
	]);
	(0, import_react.useEffect)(() => {
		playingRef.current = playing;
	}, [playing]);
	const current = items[index];
	(0, import_react.useEffect)(() => {
		const video = videoRef.current;
		if (!video) return;
		video.playbackRate = rate;
		video.volume = volume;
	}, [
		rate,
		volume,
		current?.id
	]);
	(0, import_react.useEffect)(() => {
		if (!wantPlay.current) return;
		const video = videoRef.current;
		if (!video || !current) return;
		wantPlay.current = false;
		video.play().catch(() => {
			setPlaying(false);
			flash("err", "This video could not start. Check that the archive server is running and the URL is reachable in this browser.");
		});
	}, [current?.id, index]);
	(0, import_react.useEffect)(() => {
		if (!current || !("mediaSession" in navigator)) return;
		navigator.mediaSession.metadata = new MediaMetadata({
			title: current.title,
			artist: "Archive Player"
		});
		navigator.mediaSession.setActionHandler("previoustrack", () => goPrev());
		navigator.mediaSession.setActionHandler("nexttrack", () => goNext(false));
	}, [
		current?.id,
		current?.title,
		index,
		items.length,
		shuffle,
		repeat
	]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const target = event.target;
			if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT" || target.isContentEditable)) return;
			if (event.code === "Space") {
				event.preventDefault();
				togglePlay();
			} else if (event.code === "ArrowRight") goNext(false);
			else if (event.code === "ArrowLeft") goPrev();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	const visible = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		if (!q) return items;
		return items.filter((item) => item.title.toLowerCase().includes(q) || item.url.toLowerCase().includes(q));
	}, [items, query]);
	function flash(kind, text) {
		setNotice({
			kind,
			text
		});
	}
	function jump(next, autoplay) {
		if (next < 0 || next >= items.length) return;
		if (autoplay) {
			wantPlay.current = true;
			setPlaying(true);
			if (next === index) videoRef.current?.play().catch(() => {
				setPlaying(false);
				flash("err", "This video could not start. Check that the archive server is running and the URL is reachable in this browser.");
			});
		}
		setIndex(next);
	}
	function goNext(forceWrap) {
		if (!items.length) return;
		if (shuffle && items.length > 1) {
			let next = index;
			while (next === index) next = Math.floor(Math.random() * items.length);
			jump(next, playingRef.current || forceWrap);
			return;
		}
		if (index < items.length - 1) jump(index + 1, playingRef.current || forceWrap);
		else if (repeat === "all" || forceWrap) jump(0, playingRef.current || forceWrap);
	}
	function goPrev() {
		if (!items.length) return;
		jump(index === 0 ? items.length - 1 : index - 1, playingRef.current);
	}
	function onEnded() {
		const video = videoRef.current;
		if (repeat === "one" && video) {
			video.currentTime = 0;
			video.play().catch(() => setPlaying(false));
			return;
		}
		if (index < items.length - 1 || repeat === "all" || shuffle) {
			goNext(true);
			return;
		}
		setPlaying(false);
	}
	function togglePlay() {
		const video = videoRef.current;
		if (!video || !current) return;
		if (video.paused) video.play().catch(() => flash("err", "This video could not start. Check that the archive server is running and the URL is reachable in this browser."));
		else video.pause();
	}
	function addUrls(urls) {
		const existing = new Set(items.map((item) => item.url));
		const fresh = [];
		for (const url of urls) {
			if (!url || existing.has(url) || fresh.includes(url)) continue;
			fresh.push(url);
		}
		if (!fresh.length) {
			flash("ok", "No new videos to add — those URLs are already in the playlist.");
			return 0;
		}
		const start = items.reduce((max, item) => Math.max(max, item.order), 0);
		const next = fresh.map((url, i) => ({
			id: newId(),
			url,
			title: titleFromUrl(url),
			order: start + (i + 1) * 10
		}));
		setItems((prev) => [...prev, ...next]);
		flash("ok", `Added ${next.length} video${next.length === 1 ? "" : "s"} to the playlist.`);
		return next.length;
	}
	async function scan() {
		const target = base.trim();
		if (!target) {
			flash("err", "Enter an archive viewer URL first.");
			return;
		}
		setBusy(true);
		setNotice(null);
		try {
			const response = await fetch(target);
			if (!response.ok) throw new Error(`The archive page returned ${response.status}.`);
			const urls = extractFromHtml(await response.text(), target);
			if (!urls.length) {
				flash("err", "Connected, but no video URLs were found on that page. Paste the page HTML below instead.");
				document.getElementById("paste-html")?.scrollIntoView({
					behavior: "smooth",
					block: "center"
				});
				return;
			}
			addUrls(urls);
		} catch {
			flash("err", "Direct scan was blocked — browsers refuse cross-origin fetches unless the archive sends the right headers. Paste the page HTML below, or add URLs directly. Nothing was fetched.");
			document.getElementById("paste-html")?.scrollIntoView({
				behavior: "smooth",
				block: "center"
			});
		} finally {
			setBusy(false);
		}
	}
	function parseHtml() {
		if (!htmlPaste.trim()) {
			flash("err", "Paste page HTML first.");
			return;
		}
		const urls = extractFromHtml(htmlPaste, base);
		if (!urls.length) {
			flash("err", "No video URLs found in that HTML. Try Paste Multiple URLs instead.");
			return;
		}
		flash("ok", `Found ${urls.length} video URL${urls.length === 1 ? "" : "s"} in the pasted HTML.`);
		addUrls(urls);
	}
	function addSingle() {
		const url = resolveUrl(singleUrl, base);
		if (!url) {
			flash("err", "Enter a video URL first.");
			return;
		}
		if (addUrls([url])) setSingleUrl("");
	}
	function addMany() {
		const fromText = extractUrls(multiUrls, base);
		const loose = multiUrls.split(/\s+/).map((line) => resolveUrl(line, base)).filter((url) => Boolean(url));
		const urls = [.../* @__PURE__ */ new Set([...fromText, ...loose])];
		if (!urls.length) {
			flash("err", "Paste at least one video URL, one per line.");
			return;
		}
		addUrls(urls);
	}
	function importPlaylist() {
		const urls = parseImport(importText, base);
		if (!urls.length) {
			flash("err", importText.trim() ? "No playable URLs found in that import text." : "Paste playlist JSON or M3U text first.");
			return;
		}
		addUrls(urls);
	}
	function exportPlaylist() {
		if (!items.length) {
			flash("err", "Playlist is empty — nothing to export.");
			return;
		}
		setExportText(exportKind === "json" ? toJson(items) : toM3u(items));
		flash("ok", "Export ready below. Select the text to keep a copy.");
	}
	async function copyExport() {
		exportRef.current?.select();
		try {
			await navigator.clipboard.writeText(exportText);
			setCopied(true);
		} catch {
			try {
				document.execCommand("copy");
				setCopied(true);
			} catch {
				setCopied(false);
			}
		}
		window.setTimeout(() => setCopied(false), 2e3);
	}
	function removeItem(id) {
		const removed = items.findIndex((item) => item.id === id);
		if (removed < 0) return;
		const next = items.filter((item) => item.id !== id);
		setItems(next);
		if (removed === index) setPlaying(false);
		setIndex((value) => {
			const shifted = removed < value ? value - 1 : value;
			return Math.max(0, Math.min(shifted, next.length - 1));
		});
		flash("ok", "Removed from playlist.");
	}
	function clearAll() {
		setItems([]);
		setIndex(0);
		setPlaying(false);
		setConfirmClear(false);
		flash("ok", "Playlist cleared.");
	}
	function move(from, delta) {
		const to = from + delta;
		if (to < 0 || to >= items.length) return;
		const next = items.slice();
		const a = next[from];
		const b = next[to];
		next[from] = {
			...b,
			order: a.order
		};
		next[to] = {
			...a,
			order: b.order
		};
		next.sort((x, y) => x.order - y.order);
		setItems(next);
		if (index === from) setIndex(to);
		else if (index === to) setIndex(from);
	}
	async function install() {
		if (!installEvent) {
			flash("ok", "Install prompt is not available yet. In your browser menu, use “Add to Home Screen” or “Install app” when it appears.");
			return;
		}
		try {
			await installEvent.prompt();
			setInstallEvent(null);
		} catch {
			flash("err", "Install prompt could not be opened.");
		}
	}
	async function pip() {
		const video = videoRef.current;
		try {
			if (document.pictureInPictureElement) {
				await document.exitPictureInPicture();
				return;
			}
			if (video && "requestPictureInPicture" in video) await video.requestPictureInPicture();
			else throw new Error("unavailable");
		} catch {
			flash("err", "Picture-in-picture is not available for this video in this browser.");
		}
	}
	function fullscreen() {
		const shell = shellRef.current;
		if (!shell) return;
		if (document.fullscreenElement) {
			document.exitFullscreen().catch(() => void 0);
			return;
		}
		shell.requestFullscreen?.().catch(() => void 0);
	}
	function cycleRepeat() {
		setRepeat((mode) => mode === "off" ? "all" : mode === "all" ? "one" : "off");
	}
	const repeatLabel = repeat === "off" ? "Repeat: Off" : repeat === "all" ? "Repeat: All" : "Repeat: One";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "safe-pad min-h-screen bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-bg/95 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-4 py-3 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex size-11 shrink-0 items-center justify-center rounded-xl bg-accent text-accent-ink",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, {
										className: "size-5",
										"aria-hidden": "true"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-2xl leading-none font-extrabold tracking-tight",
										children: "ARCHIVE PLAYER"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs text-muted",
										children: "Play your local archive · Saved on this device · No login"
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ml-auto flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: install,
									className: "h-11 rounded-full border border-line px-4 text-sm font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden sm:inline",
										children: "Install app"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sm:hidden",
										children: "Install"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setHelpOpen((open) => !open),
									className: "flex h-11 items-center gap-1 rounded-full border border-line px-4 text-sm font-semibold",
									"aria-expanded": helpOpen,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleHelp, {
										className: "size-4",
										"aria-hidden": "true"
									}), "Help"]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-col gap-2 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Archive viewer URL"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: base,
									onChange: (event) => setBase(event.target.value),
									className: "w-full px-3 py-2.5 font-mono text-sm break-all",
									placeholder: "Archive viewer URL",
									spellCheck: false
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: scan,
								disabled: busy,
								className: "flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl bg-accent px-5 font-bold text-accent-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanSearch, {
									className: "size-4",
									"aria-hidden": "true"
								}), busy ? "Scanning…" : "Connect / Scan"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted",
							children: "Scan asks your browser to open that page. If the archive blocks it, paste the page source below. Nothing is added until a real video URL is found."
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-7xl px-4 py-4 sm:px-6",
				children: [
					notice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						role: "status",
						className: "mb-4 flex items-start gap-2 rounded-xl border px-3 py-2.5 text-sm " + (notice.kind === "ok" ? "border-ok-line bg-ok-bg text-ok" : "border-bad-line bg-bad-bg text-bad"),
						children: [notice.kind === "ok" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "mt-0.5 size-4 shrink-0",
							"aria-hidden": "true"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
							className: "mt-0.5 size-4 shrink-0",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "break-words",
							children: notice.text
						})]
					}),
					helpOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mb-4 rounded-2xl border border-line bg-card p-4 sm:p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "flex items-center gap-2 text-lg font-bold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleHelp, {
									className: "size-5 text-accent",
									"aria-hidden": "true"
								}), "How to use with your local server"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-3 grid gap-3 text-sm leading-relaxed sm:grid-cols-2 lg:grid-cols-4",
								children: STEPS.map(([n, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-xl bg-card-2 p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-2xl font-extrabold text-accent",
										children: n
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1",
										children: text
									})]
								}, n))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs leading-relaxed text-muted",
								children: "Playlist order lives in this browser only. Playback still needs the archive server, or a video URL this browser can reach. Space plays and pauses. Left and right arrows change tracks."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid items-start gap-4 lg:grid-cols-[minmax(0,1fr)_24rem]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									ref: shellRef,
									className: "overflow-hidden rounded-2xl border border-line bg-black",
									children: current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
										ref: videoRef,
										src: current.url,
										controls: true,
										playsInline: true,
										preload: "metadata",
										className: "block aspect-video w-full bg-black",
										onPlay: () => setPlaying(true),
										onPause: () => setPlaying(false),
										onEnded,
										onLoadedMetadata: (event) => {
											const duration = event.currentTarget.duration;
											if (Number.isFinite(duration)) setDurations((prev) => ({
												...prev,
												[current.id]: duration
											}));
										},
										onError: () => flash("err", "This video could not load. Check that the archive server is running and the URL is reachable in this browser.")
									}, current.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex aspect-video flex-col items-center justify-center gap-3 px-6 text-center",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, {
												className: "size-11 text-accent",
												"aria-hidden": "true"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xl font-bold",
												children: "No video selected yet"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-sm text-muted",
												children: "Add videos below, or add the labelled demo clip to try the player."
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => addUrls([DEMO_URL]),
												className: "rounded-xl bg-accent px-4 py-2.5 text-sm font-bold text-accent-ink",
												children: "Add demo video"
											})
										]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 rounded-2xl border border-line bg-card p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-start justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-semibold tracking-widest text-accent uppercase",
													children: "Now playing"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
													className: "mt-1 text-xl leading-tight font-bold break-words",
													children: current ? current.title : "—"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "shrink-0 rounded-full border border-line px-2.5 py-1 font-mono text-sm",
												children: items.length ? `${index + 1} / ${items.length}` : "0 / 0"
											})]
										}),
										current && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: current.url,
											target: "_blank",
											rel: "noopener noreferrer",
											className: "mt-2 block font-mono text-xs break-all text-muted underline decoration-dotted",
											children: [
												current.url,
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {
													className: "inline size-3",
													"aria-hidden": "true"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4 flex flex-wrap items-center gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
													label: "Previous",
													onClick: goPrev,
													disabled: !items.length,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipBack, { className: "size-5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: togglePlay,
													disabled: !current,
													"aria-label": playing ? "Pause" : "Play",
													className: "flex size-14 items-center justify-center rounded-full bg-accent text-accent-ink",
													children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-0.5 size-6" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
													label: "Next",
													onClick: () => goNext(false),
													disabled: !items.length,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "size-5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => setShuffle((on) => !on),
													"aria-pressed": shuffle,
													className: "flex h-11 items-center gap-1.5 rounded-full border px-3 text-sm font-semibold " + (shuffle ? "border-accent text-accent" : "border-line"),
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, {
														className: "size-4",
														"aria-hidden": "true"
													}), "Shuffle"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: cycleRepeat,
													"aria-label": "Repeat",
													className: "flex h-11 items-center gap-1.5 rounded-full border px-3 text-sm font-semibold " + (repeat !== "off" ? "border-accent text-accent" : "border-line"),
													children: [repeat === "one" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat1, {
														className: "size-4",
														"aria-hidden": "true"
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, {
														className: "size-4",
														"aria-hidden": "true"
													}), repeatLabel]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => items.length && jump(0, true),
													disabled: !items.length,
													className: "h-11 rounded-full border border-line px-3 text-sm font-semibold",
													children: "Play all"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4 flex flex-wrap items-center gap-4 text-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "flex items-center gap-2",
													children: ["Speed", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
														value: rate,
														onChange: (event) => setRate(Number(event.target.value)),
														className: "px-2 py-1.5",
														children: RATES.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
															value,
															children: [value, "×"]
														}, value))
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "flex min-w-44 flex-1 items-center gap-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {
															className: "size-4",
															"aria-hidden": "true"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "sr-only",
															children: "Volume"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
															type: "range",
															min: 0,
															max: 1,
															step: .05,
															value: volume,
															onChange: (event) => setVolume(Number(event.target.value)),
															className: "w-full"
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: pip,
													className: "flex h-11 items-center gap-1.5 rounded-full border border-line px-3 text-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PictureInPicture2, {
														className: "size-4",
														"aria-hidden": "true"
													}), "PiP"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: fullscreen,
													className: "flex h-11 items-center gap-1.5 rounded-full border border-line px-3 text-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize, {
														className: "size-4",
														"aria-hidden": "true"
													}), "Fullscreen"]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 flex items-center gap-1.5 text-xs text-muted",
											children: "Autoplay next follows shuffle and repeat. Use the player bar to seek inside a video."
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 grid gap-4 md:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
										className: "rounded-2xl border border-line bg-card p-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
												className: "flex items-center gap-2 font-bold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, {
													className: "size-4 text-accent",
													"aria-hidden": "true"
												}), "Paste page HTML"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-xs text-muted",
												children: "On the archive page: View Source, copy, paste. Video, source, and link URLs are pulled out."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
												id: "paste-html",
												value: htmlPaste,
												onChange: (event) => setHtmlPaste(event.target.value),
												rows: 5,
												className: "mt-3 w-full px-3 py-2 font-mono text-xs",
												placeholder: "Paste the archive page HTML here…"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												disabled: busy,
												onClick: parseHtml,
												className: "mt-2 h-11 w-full rounded-xl bg-accent text-sm font-bold text-accent-ink",
												children: "Parse HTML and add videos"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
										className: "rounded-2xl border border-line bg-card p-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
												className: "flex items-center gap-2 font-bold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, {
													className: "size-4 text-accent",
													"aria-hidden": "true"
												}), "Add video URL"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-xs text-muted",
												children: "One direct mp4, webm, mov, or m3u8 link."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												value: singleUrl,
												onChange: (event) => setSingleUrl(event.target.value),
												className: "mt-3 w-full px-3 py-2.5 font-mono text-sm",
												placeholder: "https://…/clip.mp4",
												spellCheck: false
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												disabled: busy,
												onClick: addSingle,
												className: "mt-2 h-11 w-full rounded-xl border border-line text-sm font-bold",
												children: "Add video"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "mt-4 block text-xs font-semibold",
												children: [
													"Paste multiple URLs ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-normal text-muted",
														children: "— one per line"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
														value: multiUrls,
														onChange: (event) => setMultiUrls(event.target.value),
														rows: 3,
														className: "mt-2 w-full px-3 py-2 font-mono text-xs font-normal",
														placeholder: "https://…/one.mp4\nhttps://…/two.webm"
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												disabled: busy,
												onClick: addMany,
												className: "mt-2 h-11 w-full rounded-xl border border-line text-sm font-bold",
												children: "Add all URLs"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
									className: "mt-4 rounded-2xl border border-line bg-card p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-bold",
											children: "Import / export playlist"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 grid gap-3 md:grid-cols-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "text-xs font-semibold",
												children: ["Import JSON or M3U", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
													value: importText,
													onChange: (event) => setImportText(event.target.value),
													rows: 5,
													className: "mt-2 w-full px-3 py-2 font-mono text-xs font-normal",
													placeholder: "[{\"title\":\"Clip\",\"url\":\"https://…\"}] or #EXTM3U…"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												disabled: busy,
												onClick: importPlaylist,
												className: "mt-2 h-11 w-full rounded-xl border border-line text-sm font-bold",
												children: "Import pasted playlist"
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-semibold",
													children: "Export"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-2 flex gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
														value: exportKind,
														onChange: (event) => setExportKind(event.target.value),
														className: "px-2 py-2 text-sm",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "json",
															children: "JSON"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "m3u",
															children: "M3U"
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														onClick: exportPlaylist,
														className: "h-11 flex-1 rounded-xl bg-accent text-sm font-bold text-accent-ink",
														children: "Generate"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
													ref: exportRef,
													value: exportText,
													readOnly: true,
													rows: 5,
													className: "mt-2 w-full px-3 py-2 font-mono text-xs",
													placeholder: "Export output appears here…"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: copyExport,
													disabled: !exportText,
													className: "mt-2 h-11 w-full rounded-xl border border-line text-sm",
													children: copied ? "Copied" : "Select and copy export text"
												})
											] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-xs text-muted",
											children: "Local files cannot be opened from here. Point at them with a URL your archive server already serves."
										})
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
							className: "rounded-2xl border border-line bg-card p-4 lg:sticky lg:top-28",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "flex items-center gap-2 text-lg font-bold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListVideo, {
											className: "size-5 text-accent",
											"aria-hidden": "true"
										}), "Playlist"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rounded-full border border-line px-2 py-1 text-xs",
										children: [items.length, " videos"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "relative mt-3 block",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
											className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted",
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "sr-only",
											children: "Search playlist"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: query,
											onChange: (event) => setQuery(event.target.value),
											className: "w-full py-2.5 pr-3 pl-9 text-sm",
											placeholder: "Search title or URL…"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => items.length && jump(0, true),
										disabled: !items.length,
										className: "flex h-11 flex-1 items-center justify-center gap-1 rounded-xl bg-accent text-sm font-bold text-accent-ink",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
											className: "size-4",
											"aria-hidden": "true"
										}), "Play all"]
									}), !confirmClear ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setConfirmClear(true),
										disabled: !items.length,
										className: "h-11 flex-1 rounded-xl border border-line text-sm font-bold",
										children: "Clear all"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: clearAll,
										className: "h-11 flex-1 rounded-xl bg-bad text-sm font-bold text-accent-ink",
										children: "Confirm clear?"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 grid max-h-[36rem] gap-2 overflow-y-auto",
									children: [hydrated && !visible.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl bg-card-2 p-4 text-center text-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, {
												className: "mx-auto mb-2 size-5 text-accent",
												"aria-hidden": "true"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-semibold",
												children: query ? "No matches for that search." : "Your playlist is empty"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-xs text-muted",
												children: query ? "Try another title or URL." : "Paste page HTML or add a video URL to get started."
											})
										]
									}), visible.map((item) => {
										const position = items.findIndex((entry) => entry.id === item.id);
										const active = position === index;
										const duration = durations[item.id];
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
											className: "flex gap-2.5 rounded-xl border p-2.5 " + (active ? "border-accent bg-now" : "border-line bg-card-2"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => jump(position, true),
												"aria-label": `Play ${item.title}`,
												className: "relative flex h-12 w-16 shrink-0 flex-col items-center justify-center rounded-lg bg-black text-accent",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, {
														className: "size-4",
														"aria-hidden": "true"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-mono text-xs",
														children: String(position + 1).padStart(2, "0")
													}),
													active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1 right-1 size-2 rounded-full bg-accent" })
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0 flex-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => jump(position, true),
													className: "w-full text-left",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "block text-sm leading-snug font-semibold break-words",
															children: item.title
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "block truncate font-mono text-xs text-muted",
															children: item.url
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-xs text-muted",
															children: [
																duration ? formatDuration(duration) : "Duration after playback",
																" · ",
																item.url === "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4" ? "Demo" : "Archive"
															]
														})
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-1.5 flex gap-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
															label: "Move up",
															onClick: () => move(position, -1),
															disabled: position === 0,
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4" })
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
															label: "Move down",
															onClick: () => move(position, 1),
															disabled: position === items.length - 1,
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4" })
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															type: "button",
															onClick: () => removeItem(item.id),
															className: "ml-auto flex h-9 items-center gap-1 rounded-md border border-line px-2 text-xs",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
																className: "size-3.5",
																"aria-hidden": "true"
															}), "Remove"]
														})
													]
												})]
											})]
										}, item.id);
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-xs leading-relaxed text-muted",
									children: "Order is saved on this device. Up and down work with touch and keyboard — no account, no upload."
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "mx-auto max-w-7xl px-4 pb-8 text-xs text-muted sm:px-6",
				children: "Archive Player · Standalone · Theme #0f0f0f · Videos are added only when you paste or scan them."
			})
		]
	});
}
function IconButton({ label, onClick, disabled, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		disabled,
		className: "flex size-11 items-center justify-center rounded-full border border-line",
		children
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArchivePlayer, {});
}
//#endregion
export { Home as component };
